<nav class="navbar navbar-expand-md">
      <a class="navbar-brand" href="index.php" style="color : #000;"><b>Basic Banking System</b></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color: #000;"><b>Home</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="see_all_users.php" style="color : #000;"><b>See All Users</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="history_of_transaction.php" style="color : #000;"><b>Transaction History</b></a>
              </li>
          </div>
</nav>