# Basic Banking System

A Basic Banking System Project #1 given by The Spark Foundation
A Web based app to transfer money between different users.

Technologies used here,
HTML, CSS, Bootstrap for Frontend user interface.
PHP is used to retreive data from backend and to insert data as well.
phpMyAdmin/Xampp is used to store table data.
