# Basic Banking System

A Basic Banking System Task for GRIPSEP2022 @The Spark Foundation
A Web based app to transfer money between different users.

Technologies:
Frontend : HTML, CSS, Bootstrap 
PHP is used to retreive data from backend and to insert data as well.
phpMyAdmin/Xampp is used to store table data.
